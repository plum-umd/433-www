{-# LANGUAGE InstanceSigs, RankNTypes, TemplateHaskell #-}
module Bibtex where

import Prelude hiding ((<>))
import Control.Applicative hiding (some, many)
import Control.Monad 

import Control.Lens hiding (noneOf)

import qualified Data.Char as Char

import Text.Megaparsec
import Text.Megaparsec.Char
import Text.Megaparsec.Error

import Text.PrettyPrint (Doc, (<+>), (<>))
import qualified Text.PrettyPrint as PP

import Data.Void (Void)

-- | Data Modelling

-- | A Single Bib Entry
data Bib = Bib
  { _name  :: String
  , _title :: String
  , _procs :: String
  , _short :: String
  , _authors :: String
  , _url  :: String
  , _keys :: [String]
  , _rest :: [(String, String)]
  } deriving (Eq, Show)

data TempBib = TempBib
  { _tempName :: String
  , _entries  :: [(String, String)]
  } deriving (Eq, Show)

makeLenses ''Bib
makeLenses ''TempBib

-- | Parsec <err> <input>
type Parser = Parsec Void String

dummy :: Parser String
dummy = return "42"

main :: IO ()
main = do
  inp <- getContents
  case runParser dummy "" inp of
    Right res -> putStrLn $ show res 
    Left  err -> putStrLn $ show err

