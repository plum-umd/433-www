Code to accompany first lectures & in-class exercises for CIS 552. 

The description of these modules and in-class exercises will be posted on the
[CIS 552
website](https://www.cis.upenn.edu/~cis552/current/schedule.html). Most of
this code will not make sense without these descriptions.

