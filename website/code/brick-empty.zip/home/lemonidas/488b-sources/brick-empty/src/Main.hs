module Main
  ( main
  ) where

import UI (main)
