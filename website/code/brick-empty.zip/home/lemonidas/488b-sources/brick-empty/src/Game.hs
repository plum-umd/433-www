{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE TemplateHaskell #-}
module Game where

import Control.Applicative ((<|>))
import Control.Monad (guard)
import Data.Maybe (fromMaybe)

import Control.Lens hiding ((<|), (|>), (:>), (:<))
import Control.Monad.Trans.Maybe
import Control.Monad.Trans.State

import System.Random (Random(..), newStdGen)

-- Types

data Game = Game
  { _placeholder :: Int -- ^ placeholder comment
  } deriving (Show)

makeLenses ''Game

-- Constants

-- Functions

-- | Step forward in time
step :: Game -> Game
step s = flip execState s . runMaybeT $ do

  -- Do Nothing
  return s

-- Initialization
initGame :: IO Game
initGame = 
  return $ Game { _placeholder = 42 }
