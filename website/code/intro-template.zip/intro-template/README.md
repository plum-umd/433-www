Code to accompany first lectures & in-class exercises for CMSC 488X.
Look at the course website for more details.
